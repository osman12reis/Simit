"""Uygulama ikonunu, acilis ekranini ve Play Store gorsellerini uretir.
Gereksinim: pip install pillow
Calistir:  python3 scripts/make-art.py
"""
import math
import os
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
ASSETS = os.path.join(ROOT, "assets")
STORE = os.path.join(ROOT, "store")
os.makedirs(ASSETS, exist_ok=True)
os.makedirs(STORE, exist_ok=True)

SKY_TOP = (13, 34, 56)
SKY_MID = (37, 82, 107)
SKY_BOT = (59, 106, 126)
SIL = (10, 28, 44)
CRUST = (201, 119, 43)
CRUST_HI = (233, 162, 79)
SESAME = (251, 238, 196)
GOLD = (232, 176, 74)
BURNT = (43, 26, 20)
BURNT_HI = (106, 52, 24)
METAL = (181, 192, 199)
METAL_HI = (226, 233, 237)
METAL_LO = (140, 152, 160)

SS = 2  # supersampling


def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def gradient(w, h):
    img = Image.new("RGB", (w, h))
    px = img.load()
    for y in range(h):
        t = y / (h - 1)
        c = lerp(SKY_TOP, SKY_MID, t / 0.7) if t < 0.7 else lerp(SKY_MID, SKY_BOT, (t - 0.7) / 0.3)
        for x in range(w):
            px[x, y] = c
    return img.convert("RGBA")


def skyline(img, base_y, scale, cx):
    d = ImageDraw.Draw(img)
    s = scale
    d.rectangle([cx - 62 * s, base_y - 46 * s, cx + 62 * s, base_y], fill=SIL)
    d.pieslice([cx - 40 * s, base_y - 86 * s, cx + 40 * s, base_y - 6 * s], 180, 360, fill=SIL)
    d.rectangle([cx - 1.5 * s, base_y - 100 * s, cx + 1.5 * s, base_y - 80 * s], fill=SIL)
    for dx in (-86, 86):
        x = cx + dx * s
        d.rectangle([x - 4 * s, base_y - 120 * s, x + 4 * s, base_y], fill=SIL)
        d.polygon([(x - 6 * s, base_y - 120 * s), (x, base_y - 146 * s), (x + 6 * s, base_y - 120 * s)], fill=SIL)
    d.rectangle([0, base_y, img.width, img.height], fill=SIL)
    return img


def ring_layer(size, cx, cy, r_mid, thick, kind="normal", rot=0.3):
    """Tek bir simit halkasi icin saydam katman dondurur."""
    layer = Image.new("RGBA", size, (0, 0, 0, 0))
    base = {"normal": CRUST, "gold": (245, 196, 78), "burnt": BURNT}[kind]
    hi = {"normal": CRUST_HI, "gold": (255, 240, 176), "burnt": BURNT_HI}[kind]
    mask = Image.new("L", size, 0)
    md = ImageDraw.Draw(mask)
    ro, ri = r_mid + thick / 2, r_mid - thick / 2
    md.ellipse([cx - ro, cy - ro, cx + ro, cy + ro], fill=255)
    md.ellipse([cx - ri, cy - ri, cx + ri, cy + ri], fill=0)
    fill = Image.new("RGBA", size, base + (255,))
    layer.paste(fill, (0, 0), mask)
    d = ImageDraw.Draw(layer)
    # isik vuran ust kenar
    d.arc([cx - r_mid, cy - r_mid, cx + r_mid, cy + r_mid], 200, 315, fill=hi + (255,), width=max(2, int(thick * 0.22)))
    if kind != "burnt":
        n = 14
        for i in range(n):
            a = rot + i * (2 * math.pi / n) + (i % 2) * 0.12
            rr = r_mid + ((i % 3) - 1) * thick * 0.18
            x, y = cx + math.cos(a) * rr, cy + math.sin(a) * rr
            lw, lh = thick * 0.11, thick * 0.065
            pts = []
            for k in range(12):
                t = k / 12 * 2 * math.pi
                ex, ey = math.cos(t) * lw, math.sin(t) * lh
                pts.append((x + ex * math.cos(a) - ey * math.sin(a), y + ex * math.sin(a) + ey * math.cos(a)))
            d.polygon(pts, fill=SESAME + (255,))
    else:
        for i in range(8):
            a = rot + i * 0.8
            x, y = cx + math.cos(a) * r_mid, cy + math.sin(a) * r_mid
            d.ellipse([x - thick * 0.05, y - thick * 0.05, x + thick * 0.05, y + thick * 0.05], fill=(20, 9, 10, 255))
    return layer


def glow(size, cx, cy, r, color, alpha=160, blur=40):
    g = Image.new("RGBA", size, (0, 0, 0, 0))
    ImageDraw.Draw(g).ellipse([cx - r, cy - r, cx + r, cy + r], fill=color + (alpha,))
    return g.filter(ImageFilter.GaussianBlur(blur))


def glow_ring(size, cx, cy, r_mid, thick, color, alpha=160, blur=30):
    """Halkanin deligini doldurmayan, halka seklinde yumusak isik."""
    g = Image.new("RGBA", size, (0, 0, 0, 0))
    ro, ri = r_mid + thick / 2, r_mid - thick / 2
    ImageDraw.Draw(g).ellipse([cx - ro, cy - ro, cx + ro, cy + ro], fill=color + (alpha,))
    ImageDraw.Draw(g).ellipse([cx - ri, cy - ri, cx + ri, cy + ri], fill=(0, 0, 0, 0))
    return g.filter(ImageFilter.GaussianBlur(blur))


def tray_layer(size, cx, y, w, h):
    layer = Image.new("RGBA", size, (0, 0, 0, 0))
    sh = Image.new("RGBA", size, (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle([cx - w / 2, y + h * 0.4, cx + w / 2, y + h * 1.4], radius=h / 2, fill=(0, 0, 0, 110))
    layer.alpha_composite(sh.filter(ImageFilter.GaussianBlur(h * 0.5)))
    d = ImageDraw.Draw(layer)
    d.rounded_rectangle([cx - w / 2, y, cx + w / 2, y + h], radius=h / 2, fill=METAL + (255,))
    d.rounded_rectangle([cx - w / 2 + h * 0.3, y + h * 0.15, cx + w / 2 - h * 0.3, y + h * 0.4], radius=h * 0.15, fill=METAL_HI + (255,))
    d.rounded_rectangle([cx - w / 2 + h * 0.7, y + h * 0.75, cx + w / 2 - h * 0.7, y + h * 1.05], radius=h * 0.15, fill=METAL_LO + (255,))
    return layer


def hero(size, ring_r, ring_t, safe=1.0, with_bg=False):
    """Ikonun merkez gorseli: tepsi uzerinde duran altin parlamali simit."""
    w, h = size
    cx = w / 2
    img = gradient(w, h) if with_bg else Image.new("RGBA", size, (0, 0, 0, 0))
    ring_cy = h * 0.46
    img.alpha_composite(glow_ring(size, cx, ring_cy, ring_r, ring_t, (255, 214, 110), 150, ring_t * 0.3))
    img.alpha_composite(ring_layer(size, cx, ring_cy, ring_r, ring_t))
    tray_y = ring_cy + ring_r + ring_t / 2 + h * 0.015
    img.alpha_composite(tray_layer(size, cx, tray_y, ring_r * 2.6, ring_r * 0.2))
    return img


def save(img, path, flatten=False):
    if flatten:
        bg = Image.new("RGB", img.size, SKY_TOP)
        bg.paste(img, (0, 0), img)
        img = bg
    img.save(path)
    print("yazildi:", os.path.relpath(path, ROOT))


# ---- ikon (1024) ----
N = 1024 * SS
full = hero((N, N), ring_r=int(0.255 * N), ring_t=int(0.15 * N), with_bg=True)
icon = full.resize((1024, 1024), Image.LANCZOS)
save(icon, os.path.join(ASSETS, "icon-only.png"), flatten=True)

# adaptif ikon katmanlari: on plan merkezde, guvenli alanin (yaklasik %66) icinde kalir
fg = hero((N, N), ring_r=int(0.2 * N), ring_t=int(0.115 * N), with_bg=False).resize((1024, 1024), Image.LANCZOS)
save(fg, os.path.join(ASSETS, "icon-foreground.png"))
bgimg = gradient(1024, 1024)
save(bgimg, os.path.join(ASSETS, "icon-background.png"), flatten=True)

# Play Store ikonu 512x512
save(icon.resize((512, 512), Image.LANCZOS), os.path.join(STORE, "play-icon-512.png"), flatten=True)

# ---- acilis ekrani (2732) ----
S = 2732
splash = Image.new("RGBA", (S, S), SKY_TOP + (255,))
mark = hero((S, S), ring_r=int(S * 0.095), ring_t=int(S * 0.058), with_bg=False)
splash.alpha_composite(mark)
save(splash, os.path.join(ASSETS, "splash.png"), flatten=True)
save(splash, os.path.join(ASSETS, "splash-dark.png"), flatten=True)


# ---- one cikan gorsel 1024x500 ----
def font(size):
    for p in (
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/TTF/DejaVuSans-Bold.ttf",
        "/Library/Fonts/Arial Bold.ttf",
        "C:/Windows/Fonts/arialbd.ttf",
    ):
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()


FW, FH = 1024 * SS, 500 * SS
fg_img = gradient(FW, FH)
skyline(fg_img, int(FH * 0.94), SS * 0.9, int(FW * 0.78))
# dusen simitler
import random
random.seed(7)
spots = [(0.60, 0.16, 46, "normal"), (0.70, 0.40, 38, "gold"), (0.88, 0.22, 42, "normal"),
         (0.93, 0.55, 36, "burnt"), (0.64, 0.62, 40, "normal"), (0.80, 0.52, 34, "normal")]
for fx, fy, rr, kind in spots:
    r = rr * SS
    cx, cy = FW * fx, FH * fy
    if kind == "gold":
        fg_img.alpha_composite(glow_ring((FW, FH), cx, cy, r * 0.78, r * 0.64, (255, 214, 110), 190, r * 0.3))
    if kind == "burnt":
        fg_img.alpha_composite(glow_ring((FW, FH), cx, cy, r * 0.78, r * 0.64, (255, 90, 50), 120, r * 0.3))
    fg_img.alpha_composite(ring_layer((FW, FH), cx, cy, r * 0.78, r * 0.64, kind, rot=random.random() * 6))
fg_img.alpha_composite(tray_layer((FW, FH), FW * 0.76, FH * 0.83, 230 * SS, 24 * SS))
d = ImageDraw.Draw(fg_img)
d.text((60 * SS, 150 * SS), "Simit", font=font(104 * SS), fill=GOLD + (255,))
d.text((60 * SS, 255 * SS), "Yağmuru", font=font(104 * SS), fill=(246, 236, 218, 255))
d.text((64 * SS, 395 * SS), "Tepsiyi kaydır, simitleri yakala", font=font(30 * SS), fill=(169, 185, 196, 255))
save(fg_img.resize((1024, 500), Image.LANCZOS), os.path.join(STORE, "feature-graphic-1024x500.png"), flatten=True)
