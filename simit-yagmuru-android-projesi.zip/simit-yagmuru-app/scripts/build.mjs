// src/game.html dosyasini www/index.html olarak paketler.
// Google Fonts baglantisini kaldirir, yazi tiplerini node_modules/@fontsource icinden uygulamaya gomer.
import { readFileSync, writeFileSync, mkdirSync, copyFileSync, existsSync, rmSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const www = join(root, 'www');
const fontDir = join(www, 'fonts');

rmSync(www, { recursive: true, force: true });
mkdirSync(fontDir, { recursive: true });

// 1) Yazi tipleri: yalnizca latin ve latin-ext (Turkce karakterler latin-ext icinde)
const wanted = [
  ['bricolage-grotesque', [700, 800]],
  ['figtree', [500, 600]],
];
let fontCss = '';
let missing = [];
for (const [pkg, weights] of wanted) {
  for (const w of weights) {
    const cssPath = join(root, 'node_modules', '@fontsource', pkg, `${w}.css`);
    if (!existsSync(cssPath)) { missing.push(`${pkg} ${w}`); continue; }
    const css = readFileSync(cssPath, 'utf8');
    const blocks = css.split('@font-face').slice(1).map((b) => '@font-face' + b);
    for (let block of blocks) {
      const m = block.match(/files\/([^)]+-(?:latin|latin-ext)-\d+-normal\.woff2)/);
      if (!m) continue;
      const file = m[1];
      const src = join(root, 'node_modules', '@fontsource', pkg, 'files', file);
      if (!existsSync(src)) { missing.push(file); continue; }
      copyFileSync(src, join(fontDir, file));
      block = block
        .replace(/,\s*url\(\.\/files\/[^)]+\.woff\)\s*format\('woff'\)/g, '')
        .replace(/\.\/files\//g, './fonts/');
      fontCss += block.trim() + '\n';
    }
  }
}
writeFileSync(join(www, 'fonts.css'), fontCss);
if (missing.length) {
  console.warn('UYARI: su yazi tipi dosyalari bulunamadi, yedek yazi tipi kullanilacak:', missing.join(', '));
  console.warn('Cozum: npm install @fontsource/bricolage-grotesque @fontsource/figtree');
}

// 2) Sayfa
let html = readFileSync(join(root, 'src', 'game.html'), 'utf8');
html = html.replace(/<link[^>]*fonts\.(?:googleapis|gstatic)\.com[^>]*>\s*/g, '');
const title = (html.match(/<title>([\s\S]*?)<\/title>/) || [, 'Simit Yağmuru'])[1];
html = html.replace(/<title>[\s\S]*?<\/title>\s*/, '');
html = html.replace(/<meta name="claude:viewport-fit-sides"[^>]*>\s*/, '');
const style = (html.match(/<style>([\s\S]*?)<\/style>/) || [, ''])[1];
html = html.replace(/<style>[\s\S]*?<\/style>\s*/, '');

const page = `<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
<meta name="theme-color" content="#0d2238">
<title>${title}</title>
<link rel="stylesheet" href="fonts.css">
<style>
:root { box-sizing: border-box; padding-top: env(safe-area-inset-top, 0px); padding-bottom: env(safe-area-inset-bottom, 0px); }
body { margin: 0; }
img { max-width: 100%; }
[hidden] { display: none !important; }
</style>
<style>${style}</style>
</head>
<body>
${html.trim()}
</body>
</html>
`;
writeFileSync(join(www, 'index.html'), page);
console.log('www/index.html hazir.');
