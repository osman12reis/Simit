// "npx cap add android" sonrasi calisir: oyunu dikey (portrait) ekrana kilitler.
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const manifest = join(root, 'android', 'app', 'src', 'main', 'AndroidManifest.xml');

if (!existsSync(manifest)) {
  console.error('AndroidManifest.xml bulunamadi. Once "npx cap add android" calistir.');
  process.exit(1);
}
let xml = readFileSync(manifest, 'utf8');
if (xml.includes('android:screenOrientation')) {
  console.log('Manifest zaten yamali.');
} else {
  xml = xml.replace('<activity', '<activity\n            android:screenOrientation="portrait"');
  writeFileSync(manifest, xml);
  console.log('Manifest yamalandi: dikey ekran.');
}
