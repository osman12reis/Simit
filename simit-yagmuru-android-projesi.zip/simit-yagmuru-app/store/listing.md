# Play Store mağaza metinleri

Play Console > Mağaza varlığı > Ana mağaza girişi bölümüne yapıştır.

## Türkçe (varsayılan dil)

**Uygulama adı** (en çok 30 karakter)
Simit Yağmuru

**Kısa açıklama** (en çok 80 karakter)
Tepsiyi kaydır, düşen simitleri yakala. 8 bölüm ve sonsuz mod.

**Tam açıklama** (en çok 4000 karakter)

Simit Yağmuru, tek parmakla oynanan hızlı bir İstanbul arcade oyunu. Gökten simit yağıyor, senin elinde bir tepsi var.

Parmağını ekranda kaydır, tepsiyi sağa sola taşı ve düşen simitleri yakala. Ama dikkat: bazı simitler yanık. Yanık simiti tepsiye alırsan bir canın gider.

OYNANIŞ
• Normal simit 1 puan, altın simit 5 puan.
• Simitleri art arda yakaladıkça çarpanın x4'e kadar çıkar.
• Kaçırdığın simit çarpanını sıfırlar, bu yüzden dikkatli ol.
• 3 canın var. Yanık simit yakalarsan bir can kaybedersin.

8 BÖLÜM
Sabah Vapuru'ndan Büyük Final'e kadar her bölümde gökyüzü değişiyor ve yeni bir zorluk çıkıyor:
• Galata'da rüzgâr simitleri yan yana savuruyor.
• Martı Sürüsü bölümünde martılar havadaki simitleri kapıp kaçıyor.
• Sisli Akşam'da simitler son anda sisin içinden çıkıyor.
• Poyraz ve Büyük Final'de her şey bir arada.

Bir bölümü ne kadar az can kaybederek bitirirsen o kadar çok yıldız kazanırsın. Her bölümde 3 yıldızı toplamaya çalış.

SONSUZ MOD
Canların bitene kadar oyna, hızlandıkça zorlaşan simit yağmurunda en yüksek puanı yakala.

ÖZELLİKLER
• Tek parmakla oynanır, kısa turlar için ideal
• Hesap açmak gerekmez
• İnternet olmadan oynanır
• Ses efektleri ayarlardan kapatılabilir

## English

**App name**
Simit Rain

**Short description** (max 80)
Slide the tray and catch the falling simit. 8 levels plus endless mode.

**Full description**

Simit Rain is a fast one-finger arcade game set in Istanbul. Simit, the sesame bread ring sold on every street corner, is falling from the sky, and you are holding a tray.

Slide your finger to move the tray and catch the falling simit. Careful: some of them are burnt. Catch a burnt one and you lose a life.

HOW TO PLAY
• A regular simit is worth 1 point, a golden simit is worth 5.
• Catch simit in a row to raise your multiplier up to x4.
• Missing a simit resets your multiplier.
• You have 3 lives. A burnt simit costs one.

8 LEVELS
From Morning Ferry to the Grand Finale, the sky changes and each level adds a new challenge:
• In Galata, the wind pushes the simit sideways.
• In the seagull level, gulls snatch simit out of the air.
• In the foggy evening, simit appear out of the mist at the last moment.
• The final levels combine everything.

Finish a level with fewer lives lost to earn more stars. Try to collect 3 stars on every level.

ENDLESS MODE
Play until your lives run out and chase the highest score as the rain gets faster.

FEATURES
• One-finger controls, perfect for short sessions
• No account needed
• Works offline
• Sound effects can be turned off

## Mağaza ayarları

- Uygulama türü: Oyun
- Kategori: Arcade
- Etiketler: Arcade, Casual, Tek oyunculu (Play Console'daki listeden seç)
- İletişim e-postası: kendi e-posta adresin (herkese açık görünür)
- Gizlilik politikası: `store/privacy-policy.html` dosyasını bir web adresinde yayınla ve bağlantıyı gir

## Görseller

- Uygulama ikonu: `store/play-icon-512.png`
- Öne çıkan görsel: `store/feature-graphic-1024x500.png`
- Telefon ekran görüntüleri: en az 2 adet, kendi telefonundan al (menü, bir bölüm, sonuç ekranı). Dikey, en az 320 px, en çok 3840 px.
