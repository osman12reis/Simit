# Simit Yağmuru: Play Store'a yükleme rehberi

Bu klasör, oyunu Android uygulamasına çeviren hazır projedir. Aşağıdaki adımları sırayla izle.

Önemli not: Bu projeyi hazırlarken paket sunucusuna erişemediğim için `npm install`, `cap add android` ve Android derlemesini deneyemedim. Betikleri ve oyun kodunu söz dizimi açısından kontrol ettim, yazı tipi gömme mantığını sahte dosyalarla denedim. Bir adımda hata alırsan hata metnini bana yolla, düzeltirim.

## Klasörde ne var

| Yol | Ne işe yarar |
| --- | --- |
| `src/game.html` | Oyunun kendisi (kaynak dosya) |
| `scripts/build.mjs` | Oyunu `www/` klasörüne paketler, yazı tiplerini uygulamaya gömer |
| `scripts/patch-android.mjs` | Uygulamayı dikey ekrana kilitler |
| `scripts/make-art.py` | İkon ve mağaza görsellerini yeniden üretir (isteğe bağlı) |
| `assets/` | Uygulama ikonu ve açılış ekranı görselleri |
| `store/` | Mağaza metinleri, gizlilik politikası, 512 px ikon, öne çıkan görsel |
| `capacitor.config.json` | Uygulama adı ve paket kimliği (`com.simityagmuru.game`) |

Paket kimliğini yayınlamadan önce istediğin gibi değiştir (`capacitor.config.json` içindeki `appId`). Play Store'a ilk yüklemeden sonra değiştirilemez.

## 1. Bilgisayarına kur

- Node.js 20 veya üstü (LTS sürüm)
- Android Studio (en güncel sürüm). İlk açılışta Android SDK'yı kurmasına izin ver.

## 2. Projeyi hazırla

Terminali bu klasörde aç ve çalıştır:

```
npm install @capacitor/core @capacitor/android @fontsource/bricolage-grotesque @fontsource/figtree
npm install --save-dev @capacitor/cli @capacitor/assets
npm run setup
```

`npm run setup` şunları yapar: oyunu paketler, Android projesini oluşturur, dikey ekranı ayarlar, ikon ve açılış ekranı dosyalarını üretir ve her şeyi senkronlar.

Oyunda değişiklik yaparsan `src/game.html` dosyasını düzenle ve `npm run sync` çalıştır.

## 3. Telefonda dene

1. Telefonda Ayarlar > Geliştirici seçenekleri > USB hata ayıklamayı aç.
2. Telefonu USB ile bağla.
3. `npm run open` ile Android Studio'yu aç, Gradle işleminin bitmesini bekle.
4. Üst çubukta telefonunu seç ve yeşil Run düğmesine bas.

Menüde bölümlerin açıldığını, simitlerin düştüğünü, sesi ve kayıt sistemini (uygulamayı kapatıp açınca yıldızların durması) kontrol et.

## 4. Yayın dosyasını (AAB) oluştur

1. `android/app/build.gradle` içinde `versionCode 1` ve `versionName "1.0"` değerlerini kontrol et. Her yeni yüklemede `versionCode` bir artmalı.
2. Android Studio'da Build > Generate Signed App Bundle / APK > Android App Bundle.
3. Yeni bir keystore oluştur. Şifreleri not al ve `.jks` dosyasını güvenli bir yere yedekle. Kaybedersen uygulamayı güncelleyemezsin.
4. `release` seçeneğiyle bitir. Çıkan `.aab` dosyası Play Store'a yükleyeceğin dosyadır.

## 5. Google Play hesabı ve yükleme

1. play.google.com/console adresinde geliştirici hesabı aç. Tek seferlik 25 dolar ücret var ve kimlik doğrulaması istiyor.
2. Yeni kişisel hesaplarda yayına çıkmadan önce kapalı test (en az 12 test kullanıcısı, 14 gün) şartı olabilir. Güncel kuralı Play Console'da kontrol et ve arkadaşlarından test kullanıcısı toplamaya erken başla.
3. Play Console'da "Uygulama oluştur" de. Dil Türkçe, tür Oyun, ücretsiz seç.
4. `store/privacy-policy.html` dosyasında e-posta adresini kendininkiyle değiştir ve dosyayı bir web adresinde yayınla (GitHub Pages ve Google Sites ücretsiz seçeneklerdir). Bağlantıyı Play Console'a gir.
5. Mağaza girişini doldur: metinler `store/listing.md`, görseller `store/` klasöründe. Telefon ekran görüntülerini kendi telefonundan al.
6. Zorunlu formları doldur:
   - İçerik derecelendirme anketi (şiddet, cinsel içerik gibi içerik yok)
   - Hedef kitle: çocuklara yönelik seçeneği işaretlersen Aile politikası ve reklam kısıtları devreye girer. Önce bu seçimi düşün.
   - Veri güvenliği: şu anki sürüm hiçbir veri toplamıyor ve paylaşmıyor
   - Reklam beyanı: şu an reklam yok, "Hayır" seç
7. Kapalı test sürümünü oluştur, `.aab` dosyasını yükle, test kullanıcılarını ekle. Şart tamamlanınca üretim sürümüne başvur.
8. Google incelemesi birkaç gün sürebilir.

Google, yeni uygulamaların hedeflemesi gereken en düşük Android API seviyesini yılda bir yükseltiyor. Yükleme sırasında uyarı çıkarsa `@capacitor/android` paketini güncelle (`npm install @capacitor/android@latest @capacitor/core@latest` ve `npm install -D @capacitor/cli@latest`), sonra `npx cap sync android` çalıştır.

## 6. Gelir kazanma

Şu anki sürümde reklam ya da satın alma yok, yani indirmeler tek başına para getirmez. Seçenekler:

- **Reklam (AdMob):** admob.google.com'da hesap aç, uygulamayı ekle, reklam birimi oluştur. Projeye `@capacitor-community/admob` eklentisini kur ve bölüm sonu ekranında geçiş reklamı ya da ödüllü reklam ("bir can daha kazan") göster. Ödüllü reklam oyunculara daha az rahatsız edici gelir.
- **Reklam kaldırma satın alması:** Play Faturalandırma ile tek seferlik "reklamsız" ürünü.

Reklam eklediğinde şunları da güncelle: gizlilik politikası (reklam kimliği kullanımı), Play Console veri güvenliği formu, reklam beyanı ("Evet") ve AB/Birleşik Krallık kullanıcıları için onay penceresi (Google UMP). Kazancın vergi yükümlülüğü için bir mali müşavire danış.

Bu adımı istersen birlikte yaparız: reklam kodunu oyuna ben eklerim, sen AdMob'dan aldığın kimlikleri yazarsın.

## Sonraki güncellemeler

Yeni bölüm, yeni engel ya da denge ayarı eklemek kolay: `src/game.html` içindeki `LEVELS` listesine yeni satır eklemek yeterli. Sonra `npm run sync`, `versionCode` artır, yeni AAB oluştur ve Play Console'a yükle.
